# Scheduling experiment report

## Experiment

- Suite: obss
- Configurations: 13
- Policies: 8
- Seeds per configuration/policy: 5
- Seed range: 5001–5005
- Simulation records: 520
- Offered-traffic duration: 10.0 seconds
- Drain duration: 1.0 seconds
- Bootstrap repetitions: 10000
- Valid hypothesis tests: 637

## Methods

One simulation run is the experimental unit, not one packet.

Every policy receives the same generated workload for each case and seed.
Exogenous channel states and packet-attempt draws are independent of policy
execution order.

Summary tables contain mean, sample standard deviation, median, range,
valid/missing counts, and percentile-bootstrap 95% confidence intervals.

Comparisons pair results by case and seed. Mean differences are proposed
minus comparator. Oriented improvements reverse signs for lower-is-better
metrics, so positive values favor proposed.

Comparison intervals bootstrap paired differences. They are pointwise,
unadjusted intervals, not simultaneous confidence intervals.

Two-sided Wilcoxon signed-rank tests use Holm correction across all valid
tests in this suite. A location interpretation of Wilcoxon requires
appropriate assumptions, including symmetry of paired differences.
The tests do not directly test the mean differences shown in the plots.

Paired Cohen's dz, oriented rank-biserial effects, and run-win/tie fractions
are reported. Undefined statistics remain missing.

CPU-time measurements are descriptive only and are excluded from the
hypothesis-test family.

## Missing data and interpretation

Received-packet delay excludes undelivered packets. Read latency alongside
deadline misses, delivery fractions, and outstanding-packet counts.

Paired comparisons use complete pairs and report missing-pair counts.
Different missingness between algorithms can bias latency comparisons.

Background delivery fraction is a packet statistic, not application-flow
completion. Background goodput excludes the drain interval, while delivery
fractions can include packets received during drain.

Service-time fairness includes modeled backoff and protocol overhead.
Airtime fairness uses modeled on-air intervals and is a different metric.

Scheduler microseconds measure Python choose/complete calls. They are not
deployment overhead estimates or reliable cross-machine benchmarks.
Policy execution order is fixed, so caching/load effects can affect timings.

Mean attempt counts exclude a transmission interrupted at simulation end.

## Limits and experimental design

This is not a standards-compliant Wi-Fi MAC/PHY simulator.

The model excludes competing APs, uplink contention, full aggregation,
OFDMA, and TCP congestion control. Channel/rate sweeps are not physical
distance or interference validation.

Most sweeps change one factor at a time; they do not exhaust interactions.
Changing station count also changes total real-time offered traffic.
There is no explicit warm-up exclusion.

Background reservation is a heuristic, not a guaranteed service bound.
Baselines are established approaches, not verified current state of the art.
Recent research baselines and fair baseline-specific tuning remain necessary.

Forty seeds do not guarantee adequate power. Statistical significance does
not establish practical importance, novelty, or real-world superiority.

Constant outcomes may produce zero-width bootstrap intervals. This does
not establish certainty outside the modeled experiment.

Tune parameters using tuning data, freeze the choice, then evaluate.
Do not select the final algorithm using evaluation results and still call
those results held out. Tuning does not automatically optimize all baselines.

Holm correction is per suite. Claims combining suites require appropriate
combined analysis rather than treating each suite as independent evidence.

## Outputs

- manifest.json: configuration, environment, source fingerprints
- analysis_settings.json: statistical settings
- raw/: individual simulation JSON records
- tables/configurations.csv: model and scheduler settings
- tables/all_runs.csv: scalar run-level results
- tables/summary.csv and .md: descriptive statistics
- tables/comparisons.csv and .md: paired statistical comparisons
- plots/: PNG and PDF figures

Raw records include per-station service and airtime values.
Packet-level records are included only when --packet-logs is enabled.

## Publication status

These experiments evaluate this implementation and model only.
A current literature review, simulator validation, and stronger comparative
evidence are required before making publication-readiness claims.
